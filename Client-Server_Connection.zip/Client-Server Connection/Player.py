import pygame # type: ignore

class Player():
    def __init__(self, x, y, Width, Height, Colour):
        '''
        Initialising values for when we create the player.
        '''

        self.x = x
        self.y = y
        self.Width = Width
        self.Height = Height
        self.Colour = Colour
        self.Rect = (x, y, Width, Height)
        self.Vel = 3

    def Draw(self, Win):
        '''
        Actually creates the player, a rectangle.
        '''

        pygame.draw.rect(Win, self.Colour, self.Rect)

    def Move(self):
        '''
        Controls movement for the player.
        '''

        Keys = pygame.key.get_pressed() # Returns a dictionary of all the keys which will have a value of 0 (not pressed) and 1 (pressed).
        
        if Keys[pygame.K_a]:
            self.x -= self.Vel

        if Keys[pygame.K_d]:
            self.x += self.Vel

        if Keys[pygame.K_w]:
            self.y -= self.Vel
            
        if Keys[pygame.K_s]:
            self.y += self.Vel

        self.Update()

    def Update(self):
        self.Rect = (self.x, self.y, self.Width, self.Height)