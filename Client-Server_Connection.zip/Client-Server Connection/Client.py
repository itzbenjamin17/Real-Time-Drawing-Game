# Creating a Client

import pygame # type: ignore
from Network import Network
from Player import Player

Width = 500
Height = 500

Win = pygame.display.set_mode((Width, Height))
pygame.display.set_caption("Client")

def RedrawWindow(Win, Player, Player2):

    Win.fill((255, 255, 255))
    Player.Draw(Win)
    Player2.Draw(Win)
    pygame.display.update()

def Main():

    Run = True

    N = Network() # From the Network.py file.
    P = N.GetP()

    Clock = pygame.time.Clock()

    while Run:
        
        Clock.tick(60)
        P2 = N.Send(P)

        for Event in pygame.event.get():
            if Event.type == pygame.QUIT:
                Run = False
                pygame.quit()

        P.Move()
        RedrawWindow(Win, P, P2)

Main()