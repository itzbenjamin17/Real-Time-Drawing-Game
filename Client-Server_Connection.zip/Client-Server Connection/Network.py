# Responsible for connecting to the server.

import socket
import pickle # Used for receiving objects.

class Network:
    def __init__(self):

        self.Client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.Server = "192.168.0.11" # Make sure this is the same in the server file.
        self.Port = 5555
        self.Address = (self.Server, self.Port)
        self.P = self.Connect()

    def GetP(self):

        return self.P

    def Connect(self):

        try:
            self.Client.connect(self.Address)
            return pickle.loads(self.Client.recv(2048))
        except:
            pass

    def Send(self, Data):

        try:
            self.Client.send(pickle.dumps(Data))
            return pickle.loads(self.Client.recv(2048))
        except socket.error as Error:
            print(Error)


