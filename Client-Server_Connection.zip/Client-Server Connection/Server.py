# Creating a Server

import socket # Allows for connections to the server from a port.
from _thread import *
import sys
from Player import Player
import pickle

Server = "192.168.0.11" # LAN only.
Port = 5555 # Typically unused by other programs.

# Setting up a Socket

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

try:
    s.bind((Server, Port))
except socket.error as Error:
    print(Error)

s.listen(2) # The number inside the brackets is the upper limit of connections allowed. It is optional.
print("Waiting for a connection, Server Started")

Players = [Player(25, 25, 50, 50, (255, 0, 0)), Player(425, 425, 50, 50, (0, 0, 225))]

def ThreadedClient(Connect, Player):
    
    Connect.send(pickle.dumps(Players[Player])) # Sending the object Player.
    Reply = ""
    while True:
        try:
            Data = pickle.loads(Connect.recv(2048)) # The number in brackets is the number of bits. The larger the number, the longer it'll take to run.
            Players[Player] = Data

            if not Data:
                print("Disconnected")
                break
            else:
                if Player == 1:
                    Reply = Players[0] # If Player 1 sent the data, send back Player 2's data.
                else:
                    Reply = Players[1] # Same thing. This is to make sure that both clients see the same thing.

                print("Received:", Data)
                print("Sending:", Reply)

            Connect.sendall(pickle.dumps(Reply))
        except:
            break

    print("Lost Connection")
    Connect.close()

CurrentPlayer = 0

while True: # Continually searches for connections.

    Connection, Address = s.accept()
    print("Connected to:", Address)

    start_new_thread(ThreadedClient, (Connection, CurrentPlayer))
    CurrentPlayer += 1

