document.addEventListener('DOMContentLoaded', () => {

    const maxPlayersInput = document.getElementById('maxPlayers');
    const roundsInput = document.getElementById('rounds');
    const roundDurationInput = document.getElementById('roundDuration');
    const customWordInput = document.getElementById('customWordInput');
    const addWordBtn = document.getElementById('addWordBtn');
    const customWordsList = document.getElementById('customWordsList');
    const createRoomBtn = document.getElementById('createRoomBtn');

    let customWords = [];

    // If settings exist in localStorage, load them
    // may need to delete 
    const savedSettings = localStorage.getItem('gameSettings');
    if (savedSettings) {
      const settings = JSON.parse(savedSettings);
      maxPlayersInput.value = settings.maxPlayerCount || ''; //if some fields are empty
      roundsInput.value = settings.rounds || '';
      roundDurationInput.value = settings.roundDuration || '';
      if (Array.isArray(settings.customWords)) {
        customWords = settings.customWords;
        renderCustomWords();
      }
    }

    addWordBtn.onclick = () => {
      const word = customWordInput.value.trim();
      if (word && !customWords.includes(word)) {
        customWords.push(word);
        renderCustomWords();
        customWordInput.value = '';
      }
    };
    
    function renderCustomWords() {

        customWordsList.innerHTML = '';
        customWords.forEach((word, index) => {
        const li = document.createElement('li');
        li.textContent = word;
        const removeBtn = document.createElement('button');
        removeBtn.textContent = 'Remove';
        removeBtn.onclick = () => {
          customWords.splice(index, 1);
          renderCustomWords();
        };
        li.appendChild(removeBtn);
        customWordsList.appendChild(li);
      });
    }

    // Save settings to localStorage when the Save button is clicked
    createRoomBtn.onclick = async () => {
      const settings = {
        maxPlayerCount: Number(maxPlayersInput.value) || 5, // Added some default values in case nothing is entered.
        rounds: Number(roundsInput.value) || 3,
        roundDuration: Number(roundDurationInput.value) || 60,
        customWords: customWords
      };

      try {
        const response = await fetch('/api/create-room', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(settings)
        });

        if (!response.ok) {
          throw new Error("Failed to create room.");
        }

      localStorage.setItem('gameSettings', JSON.stringify(settings));
      alert('Creating room...');
    } catch (error) {
      console.error("Error:", error);
      alert("Failed to save settings. Please try again.");
    }
  };
});

