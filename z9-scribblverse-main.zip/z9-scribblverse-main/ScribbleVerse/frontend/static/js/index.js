let socket;

function joinRoom(event) {
    event.preventDefault();

    console.log("joinRoom() function triggered.");

    let username = document.getElementById('username').value.trim();
    let room_code = document.getElementById('room_code').value.trim();

    console.log("Username:", username);
    console.log("Room Code:", room_code);

    if (!username || !room_code) {
        alert('Please enter a username and a room code!');
        console.log("Empty username.");
        return false;
    } 

    socket = new WebSocket(`ws://${window.location.host}/ws/game/${room_code}`);
    
    socket.onopen = function () {
        console.log("Connected to WebSocket.");
        socket.send(JSON.stringify({
            'message': `${username} joined the room!`,
            'username': username
        }));
    };

    socket.onmessage = function (event) {
        let data = JSON.parse(event.data);
        console.log("Server:", data.message);
    };

    socket.onclose = function () {
        console.log("Disconnected from WebSocket.")
    };
        
    alert('Playing as ' + username + ' in room ' + room_code);
    console.log("Redirecting...")
    window.location.href = `/drawing/?room_code=${room_code}&username=${username}`;

}

async function createRoom(event) {
    console.log("createRoom() function triggered.");

    let username = document.getElementById('username').value.trim();
    console.log("Username:", username);
    if (!username) {
        alert('Please enter a username!');
        return false;
    }

    try {
        let response = await fetch("/create-room/", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({username: username})
        });

        if (!response.ok) throw new Error("Failed to set Username.");

        alert('Redirecting to Room Creator...');
        console.log(`Creating room as ${username}...`);
        window.location.href = `/create-room/?access=true`;

    } catch (error) {
        console.error("Error:", error);
        alert("Something went wrong.");
    }


    
}