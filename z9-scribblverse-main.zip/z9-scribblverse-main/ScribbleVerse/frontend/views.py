from django.shortcuts import render, redirect
from django.http import HttpResponseForbidden, JsonResponse
from api.models import *
import json

# Create your views here.
def index(request, *args, **kwargs):
    return render(request, 'frontend/index.html')

def drawing(request):
    try:
        room_code = request.GET.get("room_code")
        room = Room.objects.get(code=room_code)
        players = Player.objects.filter(room=room)
    except Room.DoesNotExist:
        return HttpResponseForbidden("Room does not exist.")

    return render(request, 'frontend/drawing.html', {"room": room, "players": players})

def showLeaderboard(request, *args, **kwargs):
    return render(request, 'frontend/leaderboard.html')

def createRoom(request):
    # Check if the request is a POST request
    #if request.method == 'POST':
    #    username = request.POST.get('username', None)
    #    return render(request, 'frontend/create room.html', {'username': username})
    #else:
    #    # If accessed directly via GET, deny access
    #    return HttpResponseForbidden("You cannot access this page directly.")

    if request.GET.get("access") != "true":
        return HttpResponseForbidden("You cannot access this page directly.")
    
    username = request.session.get("username")
    if not username:
        return JsonResponse({"error": "Username not found in session."}, status=400)

    room = Room.objects.create(code=generate_code(), host=username, num_of_players=1)
    Player.objects.create(name=username, room=room)

    request.session["room_code"] = room.code

    return redirect(f"/lobby/{room.code}/")

def joinRoom(request):
    if request.method == "POST":
        text_data_json = json.loads(request.body)
        room_code = text_data_json("room_code")
        username = text_data_json("username")

        if not username:
            return JsonResponse({"error": "Username not found in session."}, status=400)
        
        try:
            room = Room.objects.get(code=room_code)
        except Room.DoesNotExist:
            return JsonResponse({"error": "Invalid room code."}, status=400)
        
        if not Player.objects.filter(name=username, room=room).exists():
            Player.objects.create(name=username, room=room)