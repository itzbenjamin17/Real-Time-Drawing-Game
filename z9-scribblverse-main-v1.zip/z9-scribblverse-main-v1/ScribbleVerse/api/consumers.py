from channels.generic.websocket import WebsocketConsumer
from django.shortcuts import get_object_or_404
from django.template.loader import render_to_string
from asgiref.sync import async_to_sync
import json
from .models import *

class DrawingConsumer(WebsocketConsumer):
    def connect(self):
        self.user = self.scope['user']
        self.room_code = self.scope['url_route']['kwargs']['room_code']
        self.room = get_object_or_404(Room, code=self.room_code)
        
        async_to_sync(self.channel_layer.group_add)(
            self.room_code, self.channel_name
        )

        event = {
            'type': 'room_update',
            'action': 'join',
            'username': self.user.username
        }

        async_to_sync(self.channel_layer.group_add)(
            self.room_code, event
        )

        self.accept()

    def disconnect(self, close_code):
        async_to_sync(self.channel_layer.group_discard)(
            self.room_code, self.channel_name
        )

        event = {
            'type': 'room_update',
            'action': 'leave',
            'username': self.user.username
        }

        async_to_sync(self.channel_layer.group_send)(
            self.room_code, event
        )

    def receive(self, text_data):
        try:
            text_data_json = json.loads(text_data)
        except json.JSONDecodeError:
            return

        event = {
            'type': 'canvas_update',
            'data': text_data_json
        }

        if text_data_json.get("type") == "canvas_update":
            async_to_sync(self.channel_layer.group_send)(
                self.room_code, event
            )

    def canvas_update(self, event):
        self.send(text_data=json.dumps(event["data"]))

    def lobby_update(self, event):
        action = event['action']
        username = event['username']

        self.send(text_data=json.dumps({
            'type': 'room_update',
            'action': action,
            'username': username
        }))